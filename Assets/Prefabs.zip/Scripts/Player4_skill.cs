using UnityEngine;
using UnityEngine.InputSystem;

public class Mage_CrowSkill : MonoBehaviour
{
    public GameObject crowPrefab; // ������ ������
    public Transform firePoint;
    public float cooldown = 20f;
    private float nextFire;

    void Update()
    {
        // ��� - ������ ������
        if (Mouse.current.rightButton.wasPressedThisFrame && Time.time >= nextFire)
        {
            Instantiate(crowPrefab, firePoint.position, transform.rotation);
            nextFire = Time.time + cooldown;
        }
    }
}